var bannanaImg, obstacleImg, obstacleGroup, backImg, score 
function preload() {
  createCanvas(400, 400);
  backImg = loadImage("jungle.jpg");
  playerRunning = loadAnimation("Monkey_01.png", "Monkey_02.png", "Monkey_03.png", "Monkey_04.png", "Monkey_05.png", "Monkey_06.png", "Monkey_07.png", "Monkey__08.png", "Monkey_09.png", "Monkey_10.png") 
}

function setup(){
background = CreateSprite(200,200,400,400);
  background = addImage("jungle.jpg");
  //velocity?
  
  ground.visible = false
  
  player = addAnimation(playerRunning);
  background = reset;
  
  if (foodGroup.isTouching(animal)){
    score = score+2
    foodGroup = destroyEach
  }
  switch(score){
    case 10: player.scale = 0.12;
      break;
      case20:player.scale = 0.14
      break;
      case30:player.scale = 0.18
      break;
      case40:player.scale = 0.20
      default = break
  }
  if (obstacleGroup.isTouching(animal)){
    player.scale = 0.2 
    
  }
  text("score" + score, 500,500)
}

function draw() {
  background(220);
}